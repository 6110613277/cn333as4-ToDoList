//
//  ContentView.swift
//  TodoApp
//
//  Created by Siriluk Rachaniyom on 17/4/2564 BE.
//

import SwiftUI

struct ContentView: View {
    static let taskDateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }()
    
    @ObservedObject var repository: TodoRepository = TodoRepository()
    
    @State var isNewNotePresented = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(repository.todos) { todo in
                    NavigationLink(destination: ShowTodo(
                                    id: todo.id,
                                    name: todo.name,
                                    //category: todo.category,
                                    repository: repository)
                    ) {
                        HStack {
                            Image(todo.category )
                                .resizable()
                                .frame(width: 50, height: 50)
                                .padding()
                            Text(todo.name).font(.headline)
                        }
                    }
                }
                .onDelete { indexSet in
                    if let index = indexSet.first {
                        repository.remove(at: index)
                    }
                }
            }
            .navigationBarTitle("TodoApp", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {isNewNotePresented.toggle()}) {
                Image(systemName: "plus").font(.headline)
            }
            )
            .sheet(isPresented: $isNewNotePresented) {
                AddTodoView(showAddTodoView: $isNewNotePresented, repository: repository)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
