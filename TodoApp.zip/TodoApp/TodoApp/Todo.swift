//
//  Todo.swift
//  TodoApp
//
//  Created by Siriluk Rachaniyom on 26/3/2564 BE.
//

import Foundation

struct Todo: Identifiable {
    let id: String
    let name: String
    let category: String
    
    static let categoryTypes = ["family", "personal", "work"]
}
