//
//  AddTodoView.swift
//  TodoApp
//
//  Created by Siriluk Rachaniyom on 26/3/2564 BE.
//

import SwiftUI

struct AddTodoView: View {
    @State private var name = ""
    @State private var selectedCategory = 0
    @Binding var showAddTodoView: Bool
    var repository: TodoRepository
    
    private let categoryTypes = ["family", "personal", "work"]
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Add Todo").font(.largeTitle)
                TextField("Todo name", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .border(Color.black)
                    .padding()
                Text("Select category")
                Picker("", selection: $selectedCategory) {
                    ForEach(0..<categoryTypes.count) {
                        Text(categoryTypes[$0])
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            .navigationBarTitle("New Todo", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: { repository.newTodo(name: name, category: categoryTypes[selectedCategory])
                showAddTodoView = false
            }) {
                Image(systemName: "checkmark")
                    .font(.headline)
            }.disabled(name.isEmpty))
        }
        
    }
}

struct AddTodoView_Previews: PreviewProvider {
    static var previews: some View {
        AddTodoView(showAddTodoView: .constant(true), repository: TodoRepository())
    }
}
