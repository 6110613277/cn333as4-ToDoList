//
//  ShowTodo.swift
//  TodoApp
//
//  Created by Siriluk Rachaniyom on 17/4/2564 BE.
//

import SwiftUI

struct ShowTodo: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var id: String = ""
    @State var name: String = ""
    //@State var category: String = ""
    var repository: TodoRepository
    private let categoryTypes = ["family", "personal", "work"]
    @State private var selectedCategory = 0
    
    var body: some View {
        VStack {
            TextField("Name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            //TextEditor(text: $category)
                //.textFieldStyle(RoundedBorderTextFieldStyle())
            Text("Select category")
            Picker("", selection: $selectedCategory) {
                ForEach(0..<categoryTypes.count) {
                    Text(categoryTypes[$0])
                }
            }
            .pickerStyle(SegmentedPickerStyle())
        }
        .navigationBarTitle("Update Note", displayMode: .inline)
        .navigationBarItems(trailing: Button(action: { repository.updateTodo(id: id, name: name, category: categoryTypes[selectedCategory])
            presentationMode.wrappedValue.dismiss()
        }) {
            Image(systemName: "checkmark")
                .font(.headline)
        }.disabled(name.isEmpty))
    }
}

struct ShowNote_Previews: PreviewProvider {
    static var previews: some View {
        ShowTodo(id: "", repository: TodoRepository())
    }
}

