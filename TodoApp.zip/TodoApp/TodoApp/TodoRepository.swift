//
//  TodoRepository.swift
//  TodoApp
//
//  Created by Siriluk Rachaniyom on 17/4/2564 BE.
//

import Foundation
import Firebase

class TodoRepository: ObservableObject { //ใช้ ObservableObject เพราะclassนี้จะถูกนำไปใช้ในหลายๆclassถ้าเป็นObservableObjectจะทำให้ถ้าค่าเปลี่ยนมันจะไปupdateค่าให้กับทุกclassที่ใช้classนี้
    private let collectionName = "todos"
    private var db = Firestore.firestore() //สร้างตัวแปรเพื่อlinkกับfirestore
    @Published var todos: [Todo] = [] //เป็นlistของข้อมูล @Publishedเพื่อที่จะนำไปใช้แสดงข้อมูล
    
    init() {
        loadAll()
    }
    
    func newTodo(name: String, category: String) {
        db.collection(collectionName).addDocument(data: [
            "name": name,
            "category": category
        ])
        loadAll()
    }
    
    func updateTodo(id: String, name: String, category: String) {
        db.collection(collectionName).document(id).updateData([
            "name": name,
            "category": category
        ]) { error in //ที่ต้องมีerrorเผื่อในกรณีที่updateไม่สำเร็จ
            print(error ?? "Update failed.")
        }
        loadAll()
    }
    
    func remove(at index: Int) {
        let noteToDelete = todos[index] //ดึงnoteที่เราจะลบออกมา
        db.collection(collectionName).document(noteToDelete.id).delete() //.document() คือดึงมาแค่ตัวเดียว แต่ถ้า.getDocumentsคือดึงมาทุกตัว
        loadAll()
    }
    
    private func loadAll() { //ไว้โหลดข้อมูล
        db.collection(collectionName).getDocuments { (snapshot, error) in
            if let error = error {
                print(error)
                return
            }
            guard let documents = snapshot?.documents else{
                return
            }//เช็คว่า snapshotมีอะไรให้อ่านไหม ซึ่งsnapshotเป็นoptionalจึงต้องunlapมันซึ่งถ้าไม่ได้มีค่าเป็น nil ก็จะดึงdocumentsหรือข้อมูลออกมา guardมีไว้เช็คว่าค่าที่้เราจะสร้างจะไม่เป็นnilหรือก็คือดึงdocumentออกมาได้สำเร็จ ถ้าเป็นnilจะไปทำelseแทน
            self.todos = documents.compactMap {  document in//compactMapจะตัดอันที่เป็น nullทิ้ง
                let data = document.data()
                guard let name = data["name"] as? String,
                      let category = data["category"] as? String
                else {
                    return nil
                }//as?คือการcashว่าเป็นStringแต่ถ้าไม่ใช่ก็ให้เป็นnil โดยการใช้ , หมายความว่าถ้าอันแรกไม่ผ่่านก็จะไม่ไปทำอันต่อไป
                return Todo(id: document.documentID,
                            name: name,
                            category: category)
            }
        }
    }
}

